﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint0
{
    public class Wallmaster : INPC
    {
        private WallmasterStateMachine stateMachine;
        private Texture2D wallmasterSpriteSheet;
        private Rectangle source;
        private Rectangle destination;
        private IPlayer linkRef;
        private SpriteEffects flip;
        private Tuple<int, int, IPlayer, WallmasterStateMachine.Direction> init;

        public Wallmaster(int x, int y, WallmasterStateMachine.Direction d, Texture2D spritesheet, IPlayer link)
        {
            stateMachine = new WallmasterStateMachine(x, y, link, d);
            linkRef = link;
            wallmasterSpriteSheet = spritesheet;
            init = new Tuple<int, int, IPlayer, WallmasterStateMachine.Direction>(x, y, link, d);
        }

        public void Update()
        {
            stateMachine.Move();
            destination = stateMachine.GetDestination();
            source = stateMachine.GetSource();
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if(!stateMachine.IsWaiting())
            {
                WallmasterStateMachine.Direction initial = stateMachine.GetInitialDirection();
                WallmasterStateMachine.Direction second = stateMachine.GetInitialDirection();

                bool directionLeft = initial == WallmasterStateMachine.Direction.Left || second == WallmasterStateMachine.Direction.Left;
                bool directionDown = initial == WallmasterStateMachine.Direction.Down || second == WallmasterStateMachine.Direction.Down;

                if (directionLeft && directionDown)
                {
                    flip = SpriteEffects.FlipHorizontally | SpriteEffects.FlipVertically;
                }
                else if (directionLeft)
                {
                    flip = SpriteEffects.FlipHorizontally;
                }
                else if (directionDown)
                {
                    flip = SpriteEffects.FlipVertically;
                }

                spriteBatch.Draw(wallmasterSpriteSheet, destination, source, Color.White, 0, new Vector2(0, 0), flip, 0f);
            }   
        }

        public void Reset()
        {
            stateMachine = new WallmasterStateMachine(init.Item1, init.Item2, init.Item3, init.Item4);
        }
    }
}