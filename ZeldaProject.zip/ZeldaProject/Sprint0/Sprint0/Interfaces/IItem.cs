﻿using System;
using Microsoft.Xna.Framework.Graphics;
namespace Sprint0
{
    public interface IItem
    {
        public void Update();

        public void Draw(SpriteBatch spriteBatch);
    }
}
