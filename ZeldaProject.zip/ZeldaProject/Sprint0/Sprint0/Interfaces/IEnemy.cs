﻿using System;
namespace Sprint0
{
    public interface IEnemy
    {
        public void move();
    }
}
