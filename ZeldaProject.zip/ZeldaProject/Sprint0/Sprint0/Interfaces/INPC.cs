﻿using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;
namespace Sprint0
{
    public interface INPC
    {
        public void Update();
        public void Draw(SpriteBatch spriteBatch);
        public void Reset();
    }
}
