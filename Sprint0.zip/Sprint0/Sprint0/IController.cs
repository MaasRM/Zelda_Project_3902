﻿//Code by: Nathan Schultz

using System;
namespace Sprint0
{
    public interface IController
    {
        public void Update();
    }
}
